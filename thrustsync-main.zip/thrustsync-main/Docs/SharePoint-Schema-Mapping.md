# SharePoint list schema mapping

Source: `Fields.xml` (SharePoint list fields export).

This mapping focuses on the 33 visible business fields. SharePoint's built-in fields and hidden fields are omitted unless needed for migration. SQL types below are recommendations; confirm number precision and actual data before applying a migration.

## High-level application requirements

The replacement application is expected to provide:

- Replace the SharePoint List as the system used to manage these records.
- Create, read, update, and delete records (CRUD).
- A Kendo Grid with grouping, filtering, sorting, and export.
- Saved views.
- Revision history for records.
- Migration of the current SharePoint list data.
- Approximately 8–10 lookup fields.

Here, "lookup fields" refers to the application's Choice fields. Their allowed values are documented in the Choice fields section below. Implement these as selectable fields using the listed values, preserving each field's distinct option set and exact labels. Store the options in a shared table with one row per option and a natural key of `(Type, Value)`; record fields store the selected `Value` text directly rather than a foreign key.

## Business review checklist

Business confirmed that all listed fields are needed in the new system and that Engine SN is the only required field.

- **Include?** is checked for every field per the business decision.
- **Required?** is marked for Engine SN only, per the business decision.
- Calculated fields are read-only in the application.
- Engine SN can be set during creation but cannot be changed in Edit Mode.
- Fill in **Editable?** for the remaining fields to confirm whether users can change them.
- Add any business-specific validation, workflow, or migration notes.

| Field | Include? | Required? | Editable? | Business notes |
|---|---|---|---|---|
| Engine SN | [x] | Yes | Create only |  |
| Margin | [x] | No |  |  |
| General Remarks | [x] | No |  |  |
| Test Cell / Last Flight | [x] | No |  |  |
| 720 Due | [x] | No | No (calculated) |  |
| CANN Task Status | [x] | No |  |  |
| Check Preservation | [x] | No |  |  |
| Classification | [x] | No |  |  |
| Current Location | [x] | No |  |  |
| Est. Departure Date | [x] | No |  |  |
| Engine Ship Category | [x] | No |  |  |
| Engine Status | [x] | No | No (calculated) |  |
| Est Arrival Date | [x] | No |  |  |
| Indefinite Preservation Date | [x] | No |  |  |
| In Transit | [x] | No |  |  |
| Last 15 Day Humidifier Inspection | [x] | No |  |  |
| Last Preservation | [x] | No |  |  |
| Next 15 Day Humidifier Inspection Due | [x] | No | No (calculated) |  |
| Next Preservation Due | [x] | No | No (calculated) |  |
| On Dock Date | [x] | No |  |  |
| Preservation Type | [x] | No |  |  |
| Scheduled Preservation | [x] | No |  |  |
| Ship Destination | [x] | No |  |  |
| Ship Origination | [x] | No |  |  |
| Speedline | [x] | No |  |  |
| 60 Days for Alt I 180 | [x] | No | No (calculated) |  |
| Spare Engines | [x] | No | No (calculated) |  |
| Training Engine | [x] | No |  |  |
| Unserv Report Group | [x] | No | No (calculated) |  |
| Assigned to Ship | [x] | No |  |  |
| Assigned | [x] | No |  |  |
| In Grief Notes | [x] | No |  |  |

## Business fields

| SharePoint display name | SharePoint internal name | SharePoint type | Suggested SQL Server column | Notes |
|---|---|---|---|---|
| Engine SN | `Title` | Text (required) | `EngineSN nvarchar(255) NOT NULL UNIQUE` | SharePoint's required `Title` field is displayed as Engine SN. Unique key for identifying existing records during data load. |
| Margin | `Margin` | Number | `Margin decimal(18,4) NULL` | Confirm precision and scale against source values. |
| General Remarks | `General_x0020_Remarks` | Note | `GeneralRemarks nvarchar(max) NULL` | Multiple lines, rich text enabled. |
| Test Cell / Last Flight | `Test_x0020_Cell_x0020__x002f__x0` | DateTime | `TestCellLastFlight date NULL` | Date-only field. |
| 720 Due | `_x0037_20_x0020_Due` | Calculated | `Due720 date NULL` | Formula shown under [Calculated fields](#calculated-fields). |
| CANN Task Status | `CANN_x0020_In_x0020_Progress_x00` | Boolean | `CANNTaskStatus bit NULL` |  |
| Check Preservation | `Check_x0020_Preservation` | Choice | `CheckPreservation nvarchar(50) NULL` | Values listed under [Choice fields](#choice-fields). |
| Classification | `Classification` | Choice | `Classification nvarchar(30) NULL` | Values listed under [Choice fields](#choice-fields). |
| Current Location | `Current_x0020_Location` | Choice | `CurrentLocation nvarchar(255) NULL` | Values listed under [Choice fields](#choice-fields). |
| Est. Departure Date | `Est_x002e__x0020_Departure_x0020` | DateTime | `EstimatedDepartureDate date NULL` | Date-only field. |
| Engine Ship Category | `Engine_x0020_Ship_x0020_Category` | Choice | `EngineShipCategory nvarchar(30) NULL` | Values listed under [Choice fields](#choice-fields). |
| Engine Status | `Engine_x0020_Status` | Calculated | `EngineStatus nvarchar(50) NULL` | Formula shown under [Calculated fields](#calculated-fields). |
| Est Arrival Date | `Est_x0020_Arrival_x0020_Date` | DateTime | `EstimatedArrivalDate date NULL` | Date-only field. |
| Indefinite Preservation Date | `Indefinite_x0020_Preservation_x0` | DateTime | `IndefinitePreservationDate date NULL` | Date-only field. |
| In Transit | `In_x0020_Transit` | Boolean | `InTransit bit NULL` |  |
| Last 15 Day Humidifier Inspection | `Last_x0020_15_x0020_Day_x0020_Hu` | DateTime | `LastHumidifierInspectionDate date NULL` | Date-only field. |
| Last Preservation | `Last_x0020_Preservation` | DateTime | `LastPreservation date NULL` | Date-only field. |
| Next 15 Day Humidifier Inspection Due | `Next_x0020_15_x0020_Day_x0020_Hu` | Calculated | `NextHumidifierInspectionDue date NULL` | Formula shown under [Calculated fields](#calculated-fields). |
| Next Preservation Due | `Next_x0020_Preservation_x0020_Du` | Calculated | `NextPreservationDue date NULL` | Formula shown under [Calculated fields](#calculated-fields). |
| On Dock Date | `On_x0020_Dock_x0020_Date` | DateTime | `OnDockDate date NULL` | Date-only field. |
| Preservation Type | `Preservation_x0020_Type` | Choice | `PreservationType nvarchar(100) NULL` | Values listed under [Choice fields](#choice-fields). |
| Scheduled Preservation | `Scheduled_x0020_Preservation` | DateTime | `ScheduledPreservation date NULL` | Date-only field. |
| Ship Destination | `Ship_x0020_Destination` | Choice | `ShipDestination nvarchar(255) NULL` | Values listed under [Choice fields](#choice-fields). |
| Ship Origination | `Ship_x0020_Origination` | Choice | `ShipOrigination nvarchar(255) NULL` | Values listed under [Choice fields](#choice-fields). |
| Speedline | `Speedline` | Boolean | `Speedline bit NULL` |  |
| 60 Days for Alt I 180 | `_x0036_0_x0020_Days_x0020_for_x0` | Calculated | `AltI180DueDate date NULL` | Formula shown under [Calculated fields](#calculated-fields). |
| Spare Engines | `Spare_x0020_Engines` | Calculated | `SpareEngines nvarchar(50) NULL` | Formula shown under [Calculated fields](#calculated-fields). |
| Training Engine | `Training_x0020_Engine` | Boolean | `TrainingEngine bit NULL` |  |
| Unserv Report Group | `Unserv_x0020_Report_x0020_Group` | Calculated | `UnserviceableReportGroup nvarchar(100) NULL` | Formula shown under [Calculated fields](#calculated-fields). |
| Assigned to Ship | `Assigned_x0020_to_x0020_Ship0` | Text | `AssignedToShip nvarchar(255) NULL` |  |
| Assigned | `Assigned` | Text | `Assigned nvarchar(255) NULL` |  |
| In Grief Notes | `In_x0020_Grief_x0020_Notes` | Note | `InGriefNotes nvarchar(max) NULL` | Multiple lines, rich text enabled. |

## Choice fields

The schema defines these as single-value SharePoint Choice fields, not SharePoint Lookup fields. Store the selected label in the corresponding `nvarchar` record column. For application dropdowns, use a shared choice-options table with one row per allowed value: `Type` identifies the Choice field (for example, `Check Preservation`) and `Value` contains one exact option label. Enforce uniqueness on `(Type, Value)`. Bind both the displayed text and submitted value to `Value`, and filter options by `Type`. Do not use a surrogate option ID as a foreign key in the business records. Preserve exact labels, including punctuation and spelling.

| Field | Choice values |
|---|---|
| Check Preservation | `Check Preservation`; `Check 720`; `Awaiting Records` |
| Classification | `SPS`; `WRE`; `UNSERV`; `INSTALLED`; `IN-REPAIR`; `IN GRIEF` |
| Current Location | `Ali Al Salem, Kuwait`; `Altus AFB, OK`; `Al-Udeid, Qatar (En-route)`; `Andersen AFB Guam`; `Boeing Long Beach, CA (Production/Depot)`; `BSS- San Antonio, TX (Aircraft Depot)`; `Charlotte ANG, NC`; `Columbus, GA (Depot)`; `CTS Engines, FL (Depot)`; `Delta TechOps, GA (Depot)`; `Dover AFB, DE`; `Davis-Monthan, AZ`; `Edwards AFB, CA (Testing)`; `FMS-Al Udeid, Qatar`; `FMS-CAF Trenton, Canada`; `FMS-Hindan, India`; `FMS-RAAF Amberley, Australia`; `FMS-RAF Brize Norton, United Kingdom`; `FMS-SAC/NAM Papa, Hungary`; `FMS-United Arab Emirates`; `FMS-Al Mubarak, Kuwait`; `Fort A.P. Hill AAF`; `Gray Field (AAF)`; `GXO-Logistics, SC`; `Jackson ANG, MS`; `Joint-Base Lindsey Graham, SC`; `Joint-Base Lindsey Graham, SC (RAMS)`; `Joint-Base Elmendorf-Richardson, AK`; `Joint-Base Lewis-McChord, WA`; `Joint-Base McGuire-Dix-Lakehurst, NJ`; `Joint-Base Pearl Harbor-Hickam, HI`; `Kadena AB, Japan`; `Khartoum, Sudan`; `March ARB, CA`; `Martinsburg ANG, WV`; `Memphis ANG, TN`; `Pittsburgh ARB, PA`; `Prince Sultan AB, Saudi Arabia`; `Ramstein, Germany (En-Route)`; `Rota AB, Spain (En-Route)`; `San Francisco, CA (Depot)`; `Sigonella, Italy (En-Route)`; `Stewart ANG, NY`; `Tinker AFB, OK (Depot)`; `Travis AFB, CA`; `Warner-Robins ALC, GA (Depot)`; `Wright-Patterson ARB, OH`; `Warner-Robins ALC, GA (Aircraft Depot)`; `Yokota AB, Japan`; `Goose Bay AB, Canada`; `Diego Garcia` |
| Engine Ship Category | `Induction`; `Serviceable`; `Unserviceable`; `Acceptance` |
| Preservation Type | `(1) SIB`; `(2) Not Preservable`; `(3) Preservable`; `(4) Preservable, Pending MX Action` |
| Ship Destination | `Ali Al Salem, Kuwait`; `Altus AFB, OK`; `Al-Udeid, Qatar (En-route)`; `Andersen AFB Guam`; `Boeing Long Beach, CA (Production/Depot)`; `BSS- San Antonio, TX (Aircraft Depot)`; `Charlotte ANG, NC`; `Columbus, GA (Depot)`; `CTS Engines, FL (Depot)`; `Delta TechOps, GA (Depot)`; `Dover AFB, DE`; `Davis-Monthan, AZ`; `Edwards AFB, CA (Testing)`; `FMS-Al Udeid, Qatar`; `FMS-CAF Trenton, Canada`; `FMS-Hindan, India`; `FMS-RAAF Amberley, Australia`; `FMS-RAF Brize Norton, United Kingdom`; `FMS-SAC/NAM Papa, Hungary`; `FMS-United Arab Emirates`; `FMS-Al Mubarak, Kuwait`; `Fort A.P. Hill AAF`; `Gray Field (AAF)`; `GXO-Logistics, SC`; `Jackson ANG, MS`; `Joint-Base Lindsey Graham, SC`; `Joint-Base Lindsey Graham, SC (RAMS)`; `Joint-Base Elmendorf-Richardson, AK`; `Joint-Base Lewis-McChord, WA`; `Joint-Base McGuire-Dix-Lakehurst, NJ`; `Joint-Base Pearl Harbor-Hickam, HI`; `Kadena AB, Japan`; `Khartoum, Sudan`; `March ARB, CA`; `Martinsburg ANG, WV`; `Memphis ANG, TN`; `Pittsburgh ARB, PA`; `Prince Sultan AB, Saudi Arabia`; `Ramstein, Germany (En-Route)`; `Rota AB, Spain (En-Route)`; `San Francisco, CA (Depot)`; `Sigonella, Italy (En-Route)`; `Stewart ANG, NY`; `Tinker AFB, OK`; `Travis AFB, CA`; `Warner-Robins ALC, GA (Depot)`; `Wright-Patterson ARB, OH`; `Warner-Robins ALC, GA (Aircraft Depot)`; `Yokota AB, Japan` |
| Ship Origination | Same as Ship Destination, plus `In-Transit` |

The Current Location, Ship Destination, and Ship Origination choice sets are not identical. In particular, Ship Destination has `Tinker AFB, OK` while Current Location has `Tinker AFB, OK (Depot)`, and Ship Origination includes `In-Transit`.

## Calculated fields

These are the formulas present in the SharePoint schema. When importing data, choose whether to migrate SharePoint's computed result or recompute it in the application/database. If recomputing, validate SQL/.NET behavior against SharePoint for null and text edge cases.

| Field | SharePoint formula |
|---|---|
| 720 Due | `=IF([Test Cell / Last Flight]="","",[Test Cell / Last Flight]+720)` |
| Engine Status | `=IF(Classification="SPS","SPS",IF(Classification="WRE","SPS",IF(Classification="","",IF(Classification="INSTALLED","INSTALLED",IF(Classification="UNSERV","Unserviceable",IF(Classification="IN-REPAIR","Unserviceable",IF(Classification="In Grief","Unserviceable","")))))))` |
| Next 15 Day Humidifier Inspection Due | `=IF([Last 15 Day Humidifier Inspection]="","",[Last 15 Day Humidifier Inspection]+15)` |
| Next Preservation Due | `=IF([Last Preservation]="","",[Last Preservation]+180)` |
| 60 Days for Alt I 180 | `=IF([Test Cell / Last Flight]="","",IF([Last Preservation]<>"","",IF(Classification="WRE","",IF(Classification="SPS","",[Test Cell / Last Flight]+60))))` |
| Spare Engines | `=IF(Classification="","",IF(Classification<>"INSTALLED","Spare",""))` |
| Unserv Report Group | `=IF([Current Location]=OR("Columbus, GA (Depot)","Tinker AFB, OK (Depot)","Warner-Robins ALC, GA (Depot)"),"DEPOT",IF(LEFT([Current Location],4)="FMS-","FMS",IF([Current Location]="GXO Logistics, SC",[Current Location],"USAF")))` |

## Application-managed audit fields

The new application schema will include these fields. They are not sourced from the SharePoint Excel export.

| Field | During migration | After authentication is enabled |
|---|---|---|
| `CreatedBemsID` | Set to `0` | Set to the logged-in user's BEMS ID on insert |
| `CreatedDate` | Set to SQL Server `GETDATE()` | Set on insert |
| `ModifiedBemsId` | `NULL` | Set to the logged-in user's BEMS ID on update |
| `ModifiedDate` | `NULL` | Set on update |

After go-live, every insert and update must use the actual authenticated user's BEMS ID for the corresponding audit field. New records have `ModifiedBemsId` and `ModifiedDate` set to `NULL` until their first update.

## Migration notes

- Engine SN is unique and is the natural key for checking whether a record already exists during data load. Enforce uniqueness in SQL and use the mapped Engine SN value to detect matches and prevent duplicate inserts.
- The Excel export uses SharePoint display names as column headers. Map each header to its corresponding SQL field using the **SharePoint display name** and **Suggested SQL Server column** columns in the business-fields table; do not assume the Excel headers contain SharePoint internal names.
- Import calculated results from Excel into their corresponding SQL fields as part of the migration. Keep those fields read-only in the application; if the application recalculates them later, validate its results against the imported SharePoint values.
- Retain SharePoint internal names in the mapping as source-schema reference, but use the display-name-to-SQL-field mapping for the Excel import.
- Seed the shared choice-options table from the documented Choice fields and enforce uniqueness on `(Type, Value)`. Preserve a distinct option set per field, even when labels are shared.
- Validate the proposed SQL lengths against actual list data and any future values users may add.
- SharePoint system columns (for example Created, Modified, Author, Editor, and ID) are not included in the Excel export and will not be migrated. Initialize the new application-managed audit fields according to the migration rules above; after go-live, populate them from the authenticated user and current timestamp.
