using Microsoft.EntityFrameworkCore;
using ThrustSync.Core.Features.EMS.Models;
using ThrustSync.Core.Features.ThrustSync.Models;

namespace ThrustSync.Data.Context;

/// <summary>
/// EF Core DbContext for TrustSync application
/// Manages database operations for all application features
/// </summary>
public class TrustSyncDbContext : DbContext
{
    public TrustSyncDbContext(DbContextOptions<TrustSyncDbContext> options) : base(options)
    {
    }

    /// <summary>DbSet for WorkOrders</summary>
    public DbSet<WorkOrder> WorkOrders { get; set; }

    /// <summary>DbSet for Oracle snapshots</summary>
    public DbSet<OracleSnapshot> OracleSnapshots { get; set; }

    /// <summary>DbSet for KPI entries</summary>
    public DbSet<KpiEntry> KpiEntries { get; set; }

    /// <summary>DbSet for audit logs</summary>
    public DbSet<AuditLog> AuditLogs { get; set; }

    /// <summary>DbSet for export logs</summary>
    public DbSet<ExportLog> ExportLogs { get; set; }

    public DbSet<EngineRecord> EmsEngineRecords { get; set; }

    public DbSet<ChoiceOption> EmsChoiceOptions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(TrustSyncDbContext).Assembly);
    }
}
