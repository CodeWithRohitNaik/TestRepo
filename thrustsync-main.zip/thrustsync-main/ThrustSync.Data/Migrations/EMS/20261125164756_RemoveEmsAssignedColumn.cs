﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ThrustSync.Data.Migrations.EMS
{
    /// <inheritdoc />
    public partial class RemoveEmsAssignedColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Assigned",
                schema: "EMS",
                table: "EngineRecords");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Assigned",
                schema: "EMS",
                table: "EngineRecords",
                type: "nvarchar(255)",
                maxLength: 255,
                nullable: true);
        }
    }
}
