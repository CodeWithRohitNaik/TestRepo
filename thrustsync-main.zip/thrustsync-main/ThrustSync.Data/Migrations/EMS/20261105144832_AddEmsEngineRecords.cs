﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ThrustSync.Data.Migrations.EMS
{
    /// <inheritdoc />
    public partial class AddEmsEngineRecords : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "EMS");

            migrationBuilder.CreateTable(
                name: "ChoiceOptions",
                schema: "EMS",
                columns: table => new
                {
                    Type = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChoiceOptions", x => new { x.Type, x.Value });
                });

            migrationBuilder.CreateTable(
                name: "EngineRecords",
                schema: "EMS",
                columns: table => new
                {
                    EngineSN = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Margin = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: true),
                    GeneralRemarks = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TestCellLastFlight = table.Column<DateTime>(type: "date", nullable: true),
                    Due720 = table.Column<DateTime>(type: "date", nullable: true),
                    AssignedToShip = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    CANNTaskStatus = table.Column<bool>(type: "bit", nullable: true),
                    CheckPreservation = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Classification = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    CurrentLocation = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    EstimatedDepartureDate = table.Column<DateTime>(type: "date", nullable: true),
                    EngineShipCategory = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    EngineStatus = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EstimatedArrivalDate = table.Column<DateTime>(type: "date", nullable: true),
                    IndefinitePreservationDate = table.Column<DateTime>(type: "date", nullable: true),
                    InTransit = table.Column<bool>(type: "bit", nullable: true),
                    LastHumidifierInspectionDate = table.Column<DateTime>(type: "date", nullable: true),
                    LastPreservation = table.Column<DateTime>(type: "date", nullable: true),
                    NextHumidifierInspectionDue = table.Column<DateTime>(type: "date", nullable: true),
                    NextPreservationDue = table.Column<DateTime>(type: "date", nullable: true),
                    OnDockDate = table.Column<DateTime>(type: "date", nullable: true),
                    PreservationType = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ScheduledPreservation = table.Column<DateTime>(type: "date", nullable: true),
                    ShipDestination = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    ShipOrigination = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    Speedline = table.Column<bool>(type: "bit", nullable: true),
                    AltI180DueDate = table.Column<DateTime>(type: "date", nullable: true),
                    SpareEngines = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    TrainingEngine = table.Column<bool>(type: "bit", nullable: true),
                    InGriefNotes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Assigned = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    UnserviceableReportGroup = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CreatedBemsID = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModifiedBemsId = table.Column<int>(type: "int", nullable: true),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EngineRecords", x => x.EngineSN);
                });

            migrationBuilder.InsertData(
                schema: "EMS",
                table: "ChoiceOptions",
                columns: new[] { "Type", "Value" },
                values: new object[,]
                {
                    { "Check Preservation", "Awaiting Records" },
                    { "Check Preservation", "Check 720" },
                    { "Check Preservation", "Check Preservation" },
                    { "Classification", "IN GRIEF" },
                    { "Classification", "IN-REPAIR" },
                    { "Classification", "INSTALLED" },
                    { "Classification", "SPS" },
                    { "Classification", "UNSERV" },
                    { "Classification", "WRE" },
                    { "Current Location", "Al-Udeid, Qatar (En-route)" },
                    { "Current Location", "Ali Al Salem, Kuwait" },
                    { "Current Location", "Altus AFB, OK" },
                    { "Current Location", "Andersen AFB Guam" },
                    { "Current Location", "Boeing Long Beach, CA (Production/Depot)" },
                    { "Current Location", "BSS- San Antonio, TX (Aircraft Depot)" },
                    { "Current Location", "Charlotte ANG, NC" },
                    { "Current Location", "Columbus, GA (Depot)" },
                    { "Current Location", "CTS Engines, FL (Depot)" },
                    { "Current Location", "Davis-Monthan, AZ" },
                    { "Current Location", "Delta TechOps, GA (Depot)" },
                    { "Current Location", "Diego Garcia" },
                    { "Current Location", "Dover AFB, DE" },
                    { "Current Location", "Edwards AFB, CA (Testing)" },
                    { "Current Location", "FMS-Al Mubarak, Kuwait" },
                    { "Current Location", "FMS-Al Udeid, Qatar" },
                    { "Current Location", "FMS-CAF Trenton, Canada" },
                    { "Current Location", "FMS-Hindan, India" },
                    { "Current Location", "FMS-RAAF Amberley, Australia" },
                    { "Current Location", "FMS-RAF Brize Norton, United Kingdom" },
                    { "Current Location", "FMS-SAC/NAM Papa, Hungary" },
                    { "Current Location", "FMS-United Arab Emirates" },
                    { "Current Location", "Fort A.P. Hill AAF" },
                    { "Current Location", "Goose Bay AB, Canada" },
                    { "Current Location", "Gray Field (AAF)" },
                    { "Current Location", "GXO-Logistics, SC" },
                    { "Current Location", "Jackson ANG, MS" },
                    { "Current Location", "Joint-Base Elmendorf-Richardson, AK" },
                    { "Current Location", "Joint-Base Lewis-McChord, WA" },
                    { "Current Location", "Joint-Base Lindsey Graham, SC" },
                    { "Current Location", "Joint-Base Lindsey Graham, SC (RAMS)" },
                    { "Current Location", "Joint-Base McGuire-Dix-Lakehurst, NJ" },
                    { "Current Location", "Joint-Base Pearl Harbor-Hickam, HI" },
                    { "Current Location", "Kadena AB, Japan" },
                    { "Current Location", "Khartoum, Sudan" },
                    { "Current Location", "March ARB, CA" },
                    { "Current Location", "Martinsburg ANG, WV" },
                    { "Current Location", "Memphis ANG, TN" },
                    { "Current Location", "Pittsburgh ARB, PA" },
                    { "Current Location", "Prince Sultan AB, Saudi Arabia" },
                    { "Current Location", "Ramstein, Germany (En-Route)" },
                    { "Current Location", "Rota AB, Spain (En-Route)" },
                    { "Current Location", "San Francisco, CA (Depot)" },
                    { "Current Location", "Sigonella, Italy (En-Route)" },
                    { "Current Location", "Stewart ANG, NY" },
                    { "Current Location", "Tinker AFB, OK (Depot)" },
                    { "Current Location", "Travis AFB, CA" },
                    { "Current Location", "Warner-Robins ALC, GA (Aircraft Depot)" },
                    { "Current Location", "Warner-Robins ALC, GA (Depot)" },
                    { "Current Location", "Wright-Patterson ARB, OH" },
                    { "Current Location", "Yokota AB, Japan" },
                    { "Engine Ship Category", "Acceptance" },
                    { "Engine Ship Category", "Induction" },
                    { "Engine Ship Category", "Serviceable" },
                    { "Engine Ship Category", "Unserviceable" },
                    { "Preservation Type", "(1) SIB" },
                    { "Preservation Type", "(2) Not Preservable" },
                    { "Preservation Type", "(3) Preservable" },
                    { "Preservation Type", "(4) Preservable, Pending MX Action" },
                    { "Ship Destination", "Al-Udeid, Qatar (En-route)" },
                    { "Ship Destination", "Ali Al Salem, Kuwait" },
                    { "Ship Destination", "Altus AFB, OK" },
                    { "Ship Destination", "Andersen AFB Guam" },
                    { "Ship Destination", "Boeing Long Beach, CA (Production/Depot)" },
                    { "Ship Destination", "BSS- San Antonio, TX (Aircraft Depot)" },
                    { "Ship Destination", "Charlotte ANG, NC" },
                    { "Ship Destination", "Columbus, GA (Depot)" },
                    { "Ship Destination", "CTS Engines, FL (Depot)" },
                    { "Ship Destination", "Davis-Monthan, AZ" },
                    { "Ship Destination", "Delta TechOps, GA (Depot)" },
                    { "Ship Destination", "Dover AFB, DE" },
                    { "Ship Destination", "Edwards AFB, CA (Testing)" },
                    { "Ship Destination", "FMS-Al Mubarak, Kuwait" },
                    { "Ship Destination", "FMS-Al Udeid, Qatar" },
                    { "Ship Destination", "FMS-CAF Trenton, Canada" },
                    { "Ship Destination", "FMS-Hindan, India" },
                    { "Ship Destination", "FMS-RAAF Amberley, Australia" },
                    { "Ship Destination", "FMS-RAF Brize Norton, United Kingdom" },
                    { "Ship Destination", "FMS-SAC/NAM Papa, Hungary" },
                    { "Ship Destination", "FMS-United Arab Emirates" },
                    { "Ship Destination", "Fort A.P. Hill AAF" },
                    { "Ship Destination", "Gray Field (AAF)" },
                    { "Ship Destination", "GXO-Logistics, SC" },
                    { "Ship Destination", "Jackson ANG, MS" },
                    { "Ship Destination", "Joint-Base Elmendorf-Richardson, AK" },
                    { "Ship Destination", "Joint-Base Lewis-McChord, WA" },
                    { "Ship Destination", "Joint-Base Lindsey Graham, SC" },
                    { "Ship Destination", "Joint-Base Lindsey Graham, SC (RAMS)" },
                    { "Ship Destination", "Joint-Base McGuire-Dix-Lakehurst, NJ" },
                    { "Ship Destination", "Joint-Base Pearl Harbor-Hickam, HI" },
                    { "Ship Destination", "Kadena AB, Japan" },
                    { "Ship Destination", "Khartoum, Sudan" },
                    { "Ship Destination", "March ARB, CA" },
                    { "Ship Destination", "Martinsburg ANG, WV" },
                    { "Ship Destination", "Memphis ANG, TN" },
                    { "Ship Destination", "Pittsburgh ARB, PA" },
                    { "Ship Destination", "Prince Sultan AB, Saudi Arabia" },
                    { "Ship Destination", "Ramstein, Germany (En-Route)" },
                    { "Ship Destination", "Rota AB, Spain (En-Route)" },
                    { "Ship Destination", "San Francisco, CA (Depot)" },
                    { "Ship Destination", "Sigonella, Italy (En-Route)" },
                    { "Ship Destination", "Stewart ANG, NY" },
                    { "Ship Destination", "Tinker AFB, OK" },
                    { "Ship Destination", "Travis AFB, CA" },
                    { "Ship Destination", "Warner-Robins ALC, GA (Aircraft Depot)" },
                    { "Ship Destination", "Warner-Robins ALC, GA (Depot)" },
                    { "Ship Destination", "Wright-Patterson ARB, OH" },
                    { "Ship Destination", "Yokota AB, Japan" },
                    { "Ship Origination", "Al-Udeid, Qatar (En-route)" },
                    { "Ship Origination", "Ali Al Salem, Kuwait" },
                    { "Ship Origination", "Altus AFB, OK" },
                    { "Ship Origination", "Andersen AFB Guam" },
                    { "Ship Origination", "Boeing Long Beach, CA (Production/Depot)" },
                    { "Ship Origination", "BSS- San Antonio, TX (Aircraft Depot)" },
                    { "Ship Origination", "Charlotte ANG, NC" },
                    { "Ship Origination", "Columbus, GA (Depot)" },
                    { "Ship Origination", "CTS Engines, FL (Depot)" },
                    { "Ship Origination", "Davis-Monthan, AZ" },
                    { "Ship Origination", "Delta TechOps, GA (Depot)" },
                    { "Ship Origination", "Dover AFB, DE" },
                    { "Ship Origination", "Edwards AFB, CA (Testing)" },
                    { "Ship Origination", "FMS-Al Mubarak, Kuwait" },
                    { "Ship Origination", "FMS-Al Udeid, Qatar" },
                    { "Ship Origination", "FMS-CAF Trenton, Canada" },
                    { "Ship Origination", "FMS-Hindan, India" },
                    { "Ship Origination", "FMS-RAAF Amberley, Australia" },
                    { "Ship Origination", "FMS-RAF Brize Norton, United Kingdom" },
                    { "Ship Origination", "FMS-SAC/NAM Papa, Hungary" },
                    { "Ship Origination", "FMS-United Arab Emirates" },
                    { "Ship Origination", "Fort A.P. Hill AAF" },
                    { "Ship Origination", "Gray Field (AAF)" },
                    { "Ship Origination", "GXO-Logistics, SC" },
                    { "Ship Origination", "In-Transit" },
                    { "Ship Origination", "Jackson ANG, MS" },
                    { "Ship Origination", "Joint-Base Elmendorf-Richardson, AK" },
                    { "Ship Origination", "Joint-Base Lewis-McChord, WA" },
                    { "Ship Origination", "Joint-Base Lindsey Graham, SC" },
                    { "Ship Origination", "Joint-Base Lindsey Graham, SC (RAMS)" },
                    { "Ship Origination", "Joint-Base McGuire-Dix-Lakehurst, NJ" },
                    { "Ship Origination", "Joint-Base Pearl Harbor-Hickam, HI" },
                    { "Ship Origination", "Kadena AB, Japan" },
                    { "Ship Origination", "Khartoum, Sudan" },
                    { "Ship Origination", "March ARB, CA" },
                    { "Ship Origination", "Martinsburg ANG, WV" },
                    { "Ship Origination", "Memphis ANG, TN" },
                    { "Ship Origination", "Pittsburgh ARB, PA" },
                    { "Ship Origination", "Prince Sultan AB, Saudi Arabia" },
                    { "Ship Origination", "Ramstein, Germany (En-Route)" },
                    { "Ship Origination", "Rota AB, Spain (En-Route)" },
                    { "Ship Origination", "San Francisco, CA (Depot)" },
                    { "Ship Origination", "Sigonella, Italy (En-Route)" },
                    { "Ship Origination", "Stewart ANG, NY" },
                    { "Ship Origination", "Tinker AFB, OK" },
                    { "Ship Origination", "Travis AFB, CA" },
                    { "Ship Origination", "Warner-Robins ALC, GA (Aircraft Depot)" },
                    { "Ship Origination", "Warner-Robins ALC, GA (Depot)" },
                    { "Ship Origination", "Wright-Patterson ARB, OH" },
                    { "Ship Origination", "Yokota AB, Japan" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ChoiceOptions",
                schema: "EMS");

            migrationBuilder.DropTable(
                name: "EngineRecords",
                schema: "EMS");

        }
    }
}
