using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TrustSync.Data.Migrations.ThrustSync
{
    public partial class DropPartColumns : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Drop indices if present
            migrationBuilder.DropIndex(
                name: "IX_WorkOrders_PartNumber",
                table: "WorkOrders");

            migrationBuilder.DropIndex(
                name: "IX_WorkOrders_PartSerialNumber",
                table: "WorkOrders");

            // Drop the columns
            migrationBuilder.DropColumn(
                name: "PartNumber",
                table: "WorkOrders");

            migrationBuilder.DropColumn(
                name: "PartSerialNumber",
                table: "WorkOrders");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PartNumber",
                table: "WorkOrders",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PartSerialNumber",
                table: "WorkOrders",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrders_PartNumber",
                table: "WorkOrders",
                column: "PartNumber");

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrders_PartSerialNumber",
                table: "WorkOrders",
                column: "PartSerialNumber");
        }
    }
}
