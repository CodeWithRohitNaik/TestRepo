﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TrustSync.Data.Migrations.ThrustSync
{
    /// <inheritdoc />
    public partial class RemoveApuEntity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkOrders_APUs_ApuId",
                table: "WorkOrders");

            migrationBuilder.DropTable(
                name: "APUs");

            migrationBuilder.DropIndex(
                name: "IX_WorkOrders_ApuId",
                table: "WorkOrders");

            migrationBuilder.RenameColumn(
                name: "ApuId",
                table: "WorkOrders",
                newName: "FailureCode");

            migrationBuilder.AddColumn<string>(
                name: "PartNumber",
                table: "WorkOrders",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PartSerialNumber",
                table: "WorkOrders",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PartSerialString",
                table: "WorkOrders",
                type: "nvarchar(300)",
                maxLength: 300,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "RefDes",
                table: "WorkOrders",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "RemovalIndicator",
                table: "WorkOrders",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ReviewStatus",
                table: "WorkOrders",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrders_PartNumber",
                table: "WorkOrders",
                column: "PartNumber");

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrders_PartSerialNumber",
                table: "WorkOrders",
                column: "PartSerialNumber");

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrders_PartSerialString",
                table: "WorkOrders",
                column: "PartSerialString");

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrders_RefDes",
                table: "WorkOrders",
                column: "RefDes");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_WorkOrders_PartNumber",
                table: "WorkOrders");

            migrationBuilder.DropIndex(
                name: "IX_WorkOrders_PartSerialNumber",
                table: "WorkOrders");

            migrationBuilder.DropIndex(
                name: "IX_WorkOrders_PartSerialString",
                table: "WorkOrders");

            migrationBuilder.DropIndex(
                name: "IX_WorkOrders_RefDes",
                table: "WorkOrders");

            migrationBuilder.DropColumn(
                name: "PartNumber",
                table: "WorkOrders");

            migrationBuilder.DropColumn(
                name: "PartSerialNumber",
                table: "WorkOrders");

            migrationBuilder.DropColumn(
                name: "PartSerialString",
                table: "WorkOrders");

            migrationBuilder.DropColumn(
                name: "RefDes",
                table: "WorkOrders");

            migrationBuilder.DropColumn(
                name: "RemovalIndicator",
                table: "WorkOrders");

            migrationBuilder.DropColumn(
                name: "ReviewStatus",
                table: "WorkOrders");

            migrationBuilder.RenameColumn(
                name: "FailureCode",
                table: "WorkOrders",
                newName: "ApuId");

            migrationBuilder.CreateTable(
                name: "APUs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FailureCode = table.Column<int>(type: "int", nullable: true),
                    PartNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PartSerialNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    RefDes = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    RemovalIndicator = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    ReviewStatus = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_APUs", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrders_ApuId",
                table: "WorkOrders",
                column: "ApuId");

            migrationBuilder.CreateIndex(
                name: "IX_APUs_PartNumber",
                table: "APUs",
                column: "PartNumber");

            migrationBuilder.CreateIndex(
                name: "IX_APUs_PartSerialNumber",
                table: "APUs",
                column: "PartSerialNumber");

            migrationBuilder.CreateIndex(
                name: "IX_APUs_RefDes",
                table: "APUs",
                column: "RefDes");

            migrationBuilder.CreateIndex(
                name: "IX_APUs_RefDes_PartNumber_PartSerialNumber",
                table: "APUs",
                columns: new[] { "RefDes", "PartNumber", "PartSerialNumber" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_WorkOrders_APUs_ApuId",
                table: "WorkOrders",
                column: "ApuId",
                principalTable: "APUs",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);
        }
    }
}
