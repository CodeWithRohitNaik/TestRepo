using System;
using Microsoft.EntityFrameworkCore;
using ThrustSync.Core.Features.ThrustSync.Models;
using ThrustSync.Core.Features.ThrustSync.Repositories;
using ThrustSync.Data.Context;

namespace ThrustSync.Data.Features.ThrustSync.Repositories;

/// <summary>
/// Repository implementation for WorkOrder operations
/// </summary>
public class WorkOrderRepository : Repository<WorkOrder>, IWorkOrderRepository
{
    public WorkOrderRepository(TrustSyncDbContext context) : base(context)
    {
    }

    public async Task<(IEnumerable<WorkOrder> Items, int Total)> GetFilteredWorkOrdersAsync(
        int skip, int take,
        string? jcn = null,
        string? fracpr = null,
        string? mid = null,
        string? tailNumber = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        string? sortBy = null,
        string sortDirection = "asc")
    {
        var query = _dbSet.AsQueryable();

        if (!string.IsNullOrWhiteSpace(jcn))
            query = query.Where(w => w.JCN.Contains(jcn));

        if (!string.IsNullOrWhiteSpace(fracpr))
            query = query.Where(w => w.FRACPR.Contains(fracpr));

        if (!string.IsNullOrWhiteSpace(mid))
            query = query.Where(w => w.MID.Contains(mid));

        if (!string.IsNullOrWhiteSpace(tailNumber))
            query = query.Where(w => w.TailNumber != null && w.TailNumber.Contains(tailNumber));

        if (fromDate.HasValue)
            query = query.Where(w => w.CreatedDate >= fromDate.Value);

        if (toDate.HasValue)
            query = query.Where(w => w.CreatedDate <= toDate.Value.AddDays(1));

        var total = await query.CountAsync();

        var normalizedDirection = string.Equals(sortDirection, "desc", StringComparison.OrdinalIgnoreCase)
            ? "desc" : "asc";

        if (string.IsNullOrWhiteSpace(sortBy))
        {
            query = query.OrderByDescending(w => w.CreatedDate);
        }
        else
        {
            switch (sortBy.Trim())
            {
                case "JCN":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.JCN)
                        : query.OrderBy(w => w.JCN);
                    break;
                case "FRACPR":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.FRACPR)
                        : query.OrderBy(w => w.FRACPR);
                    break;
                case "MID":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.MID)
                        : query.OrderBy(w => w.MID);
                    break;
                case "TailNumber":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.TailNumber)
                        : query.OrderBy(w => w.TailNumber);
                    break;
                case "HMC":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.HMC)
                        : query.OrderBy(w => w.HMC);
                    break;
                case "FAC":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.FAC)
                        : query.OrderBy(w => w.FAC);
                    break;
                case "CreatedDate":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.CreatedDate)
                        : query.OrderBy(w => w.CreatedDate);
                    break;
                case "LastKpiUpdatedOn":
                    query = normalizedDirection == "desc"
                        ? query.OrderByDescending(w => w.LastKpiUpdatedOn)
                        : query.OrderBy(w => w.LastKpiUpdatedOn);
                    break;
                default:
                    query = query.OrderByDescending(w => w.CreatedDate);
                    break;
            }
        }

        var items = await query
            .Include(w => w.KpiEntries)
            .Skip(skip)
            .Take(take)
            .ToListAsync();

        return (items, total);
    }

    public async Task<WorkOrder?> GetWorkOrderWithDetailsAsync(int id)
    {
        return await _dbSet
            .Include(w => w.OracleSnapshot)
            .Include(w => w.KpiEntries.OrderByDescending(k => k.EnteredOn))
            .Include(w => w.AuditLogs.OrderByDescending(a => a.ChangedOn))
            .FirstOrDefaultAsync(w => w.Id == id);
    }

    public async Task<IEnumerable<WorkOrder>> GetWorkOrdersForKpiUpdateAsync(int days = 30)
    {
        var cutoffDate = DateTime.UtcNow.AddDays(-days);
        
        return await _dbSet
            .Where(w => w.LastKpiUpdatedOn == null || w.LastKpiUpdatedOn < cutoffDate)
            .Include(w => w.KpiEntries)
            .ToListAsync();
    }
}
