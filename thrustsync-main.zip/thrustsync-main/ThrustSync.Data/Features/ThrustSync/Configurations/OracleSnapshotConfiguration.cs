using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ThrustSync.Core.Features.ThrustSync.Models;

namespace ThrustSync.Data.Features.ThrustSync.Configurations;

public class OracleSnapshotConfiguration : IEntityTypeConfiguration<OracleSnapshot>
{
    public void Configure(EntityTypeBuilder<OracleSnapshot> entity)
    {
        entity.HasKey(e => e.Id);

        entity.HasIndex(e => e.PulledOn);
        entity.HasIndex(e => e.WorkOrderId).IsUnique();

        entity.Property(e => e.SourceData)
            .IsRequired()
            .HasColumnType("nvarchar(max)");
    }
}
