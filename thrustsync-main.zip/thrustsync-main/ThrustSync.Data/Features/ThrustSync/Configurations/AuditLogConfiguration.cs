using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ThrustSync.Core.Features.ThrustSync.Models;

namespace ThrustSync.Data.Features.ThrustSync.Configurations;

public class AuditLogConfiguration : IEntityTypeConfiguration<AuditLog>
{
    public void Configure(EntityTypeBuilder<AuditLog> entity)
    {
        entity.HasKey(e => e.Id);

        entity.HasIndex(e => e.WorkOrderId);
        entity.HasIndex(e => e.ChangedOn);
        entity.HasIndex(e => e.ChangedBy);

        entity.Property(e => e.ChangeType)
            .IsRequired()
            .HasMaxLength(50);

        entity.Property(e => e.FieldName)
            .HasMaxLength(100);

        entity.Property(e => e.OldValue)
            .HasMaxLength(500);

        entity.Property(e => e.NewValue)
            .HasMaxLength(500);

        entity.Property(e => e.ChangedBy)
            .IsRequired()
            .HasMaxLength(256);
    }
}
