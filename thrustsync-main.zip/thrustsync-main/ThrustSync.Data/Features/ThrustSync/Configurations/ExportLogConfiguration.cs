using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ThrustSync.Core.Features.ThrustSync.Models;

namespace ThrustSync.Data.Features.ThrustSync.Configurations;

public class ExportLogConfiguration : IEntityTypeConfiguration<ExportLog>
{
    public void Configure(EntityTypeBuilder<ExportLog> entity)
    {
        entity.HasKey(e => e.Id);

        entity.HasIndex(e => e.ExportedOn);
        entity.HasIndex(e => e.ExportedBy);

        entity.Property(e => e.ExportedBy)
            .IsRequired()
            .HasMaxLength(256);

        entity.Property(e => e.FilterCriteria)
            .HasMaxLength(1000);
    }
}
