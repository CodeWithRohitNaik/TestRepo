using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ThrustSync.Core.Features.ThrustSync.Models;

namespace ThrustSync.Data.Features.ThrustSync.Configurations;

public class KpiEntryConfiguration : IEntityTypeConfiguration<KpiEntry>
{
    public void Configure(EntityTypeBuilder<KpiEntry> entity)
    {
        entity.HasKey(e => e.Id);

        entity.HasIndex(e => e.WorkOrderId);
        entity.HasIndex(e => e.EnteredOn);

        entity.Property(e => e.EnteredBy)
            .IsRequired()
            .HasMaxLength(256);

        entity.Property(e => e.Source)
            .IsRequired()
            .HasMaxLength(50);

        entity.Property(e => e.FlightHours)
            .HasPrecision(18, 2);

        entity.Property(e => e.OtherHours)
            .HasPrecision(18, 2);

        entity.Property(e => e.OpTime)
            .HasPrecision(18, 2);

        entity.Property(e => e.Notes)
            .HasMaxLength(1000);
    }
}
