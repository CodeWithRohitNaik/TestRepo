using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ThrustSync.Core.Features.ThrustSync.Models;

namespace ThrustSync.Data.Features.ThrustSync.Configurations;

public class WorkOrderConfiguration : IEntityTypeConfiguration<WorkOrder>
{
    public void Configure(EntityTypeBuilder<WorkOrder> entity)
    {
        entity.HasKey(e => e.Id);

        entity.HasIndex(e => e.JCN);
        entity.HasIndex(e => e.FRACPR).IsUnique();
        entity.HasIndex(e => e.MID);
        entity.HasIndex(e => e.TailNumber);
        entity.HasIndex(e => e.CreatedDate);
        entity.HasIndex(e => e.OraclePulledOn);
        entity.HasIndex(e => e.RefDes);
        entity.HasIndex(e => e.PartSerialString);

        entity.Property(e => e.JCN)
            .IsRequired()
            .HasMaxLength(50);

        entity.Property(e => e.FRACPR)
            .IsRequired()
            .HasMaxLength(50);

        entity.Property(e => e.MID)
            .IsRequired()
            .HasMaxLength(500);

        entity.Property(e => e.TailNumber)
            .HasMaxLength(50);

        entity.Property(e => e.RefDes)
            .HasMaxLength(50);

        entity.Property(e => e.PartSerialString)
            .HasMaxLength(300);

        entity.Property(e => e.RemovalIndicator)
            .HasMaxLength(10);

        entity.Property(e => e.ReviewStatus)
            .HasMaxLength(10);

        entity.HasOne(e => e.OracleSnapshot)
            .WithOne(os => os.WorkOrder)
            .HasForeignKey<OracleSnapshot>(os => os.WorkOrderId)
            .OnDelete(DeleteBehavior.Cascade);

        entity.HasMany(e => e.KpiEntries)
            .WithOne(k => k.WorkOrder)
            .HasForeignKey(k => k.WorkOrderId)
            .OnDelete(DeleteBehavior.Cascade);

        entity.HasMany(e => e.AuditLogs)
            .WithOne(a => a.WorkOrder)
            .HasForeignKey(a => a.WorkOrderId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
