using Microsoft.EntityFrameworkCore;
using ThrustSync.Core.Features.EMS.Models;
using ThrustSync.Core.Features.EMS.Repositories;
using ThrustSync.Data.Context;

namespace ThrustSync.Data.Features.EMS.Repositories;

public class EmsEngineRecordRepository : IEmsEngineRecordRepository
{
    private readonly TrustSyncDbContext _dbContext;

    public EmsEngineRecordRepository(TrustSyncDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<(IReadOnlyList<EngineRecord> Items, int Total, int Page)> GetPageAsync(
        int page,
        int pageSize,
        string? search,
        string sortBy,
        bool descending)
    {
        var query = _dbContext.EmsEngineRecords.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(record =>
                record.EngineSN.Contains(search) ||
                (record.Classification != null && record.Classification.Contains(search)) ||
                (record.CurrentLocation != null && record.CurrentLocation.Contains(search)) ||
                (record.EngineStatus != null && record.EngineStatus.Contains(search)));
        }

        var total = await query.CountAsync();
        var maxPage = Math.Max(1, (int)Math.Ceiling(total / (double)pageSize));
        page = Math.Min(page, maxPage);

        query = sortBy switch
        {
            "Classification" => descending
                ? query.OrderByDescending(record => record.Classification).ThenBy(record => record.EngineSN)
                : query.OrderBy(record => record.Classification).ThenBy(record => record.EngineSN),
            "CurrentLocation" => descending
                ? query.OrderByDescending(record => record.CurrentLocation).ThenBy(record => record.EngineSN)
                : query.OrderBy(record => record.CurrentLocation).ThenBy(record => record.EngineSN),
            "EngineStatus" => descending
                ? query.OrderByDescending(record => record.EngineStatus).ThenBy(record => record.EngineSN)
                : query.OrderBy(record => record.EngineStatus).ThenBy(record => record.EngineSN),
            _ => descending
                ? query.OrderByDescending(record => record.EngineSN)
                : query.OrderBy(record => record.EngineSN)
        };

        var items = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        return (items, total, page);
    }

    public Task<EngineRecord?> GetByEngineSNAsync(string engineSN) =>
        _dbContext.EmsEngineRecords
            .AsNoTracking()
            .FirstOrDefaultAsync(record => record.EngineSN == engineSN);

    public Task<bool> ExistsAsync(string engineSN) =>
        _dbContext.EmsEngineRecords.AnyAsync(record => record.EngineSN == engineSN);

    public async Task<Dictionary<string, List<string>>> GetChoiceOptionsAsync()
    {
        var options = await _dbContext.EmsChoiceOptions
            .AsNoTracking()
            .OrderBy(option => option.Type)
            .ThenBy(option => option.Value)
            .ToListAsync();

        return options
            .GroupBy(option => option.Type)
            .ToDictionary(group => group.Key, group => group.Select(option => option.Value).ToList());
    }

    public async Task AddAsync(EngineRecord record)
    {
        await _dbContext.EmsEngineRecords.AddAsync(record);
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateAsync(EngineRecord record)
    {
        _dbContext.EmsEngineRecords.Update(record);
        await _dbContext.SaveChangesAsync();
    }
}
