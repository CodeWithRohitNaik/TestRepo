using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ThrustSync.Core.Features.EMS.Models;

namespace ThrustSync.Data.Features.EMS.Configurations;

public class EngineRecordConfiguration : IEntityTypeConfiguration<EngineRecord>
{
    public void Configure(EntityTypeBuilder<EngineRecord> entity)
    {
        entity.ToTable("EngineRecords", "EMS");
        entity.HasKey(record => record.EngineSN);

        entity.Property(record => record.EngineSN)
            .HasMaxLength(255)
            .IsRequired();

        entity.Property(record => record.Margin)
            .HasPrecision(18, 4);

        entity.Property(record => record.GeneralRemarks)
            .HasColumnType("nvarchar(max)");

        entity.Property(record => record.TestCellLastFlight).HasColumnType("date");
        entity.Property(record => record.Due720).HasColumnType("date");
        entity.Property(record => record.EstimatedDepartureDate).HasColumnType("date");
        entity.Property(record => record.EstimatedArrivalDate).HasColumnType("date");
        entity.Property(record => record.IndefinitePreservationDate).HasColumnType("date");
        entity.Property(record => record.LastHumidifierInspectionDate).HasColumnType("date");
        entity.Property(record => record.LastPreservation).HasColumnType("date");
        entity.Property(record => record.NextHumidifierInspectionDue).HasColumnType("date");
        entity.Property(record => record.NextPreservationDue).HasColumnType("date");
        entity.Property(record => record.OnDockDate).HasColumnType("date");
        entity.Property(record => record.ScheduledPreservation).HasColumnType("date");
        entity.Property(record => record.AltI180DueDate).HasColumnType("date");

        entity.Property(record => record.AssignedToShip).HasMaxLength(255);
        entity.Property(record => record.CheckPreservation).HasMaxLength(50);
        entity.Property(record => record.Classification).HasMaxLength(30);
        entity.Property(record => record.CurrentLocation).HasMaxLength(255);
        entity.Property(record => record.EngineShipCategory).HasMaxLength(30);
        entity.Property(record => record.EngineStatus).HasMaxLength(50);
        entity.Property(record => record.PreservationType).HasMaxLength(100);
        entity.Property(record => record.ShipDestination).HasMaxLength(255);
        entity.Property(record => record.ShipOrigination).HasMaxLength(255);
        entity.Property(record => record.SpareEngines).HasMaxLength(50);
        entity.Property(record => record.Assigned).HasMaxLength(255);
        entity.Property(record => record.UnserviceableReportGroup).HasMaxLength(100);
        entity.Property(record => record.InGriefNotes).HasColumnType("nvarchar(max)");

        entity.Property(record => record.CreatedBemsID)
            .HasDefaultValue(0);
        entity.Property(record => record.CreatedDate)
            .HasDefaultValueSql("GETDATE()");
    }
}
