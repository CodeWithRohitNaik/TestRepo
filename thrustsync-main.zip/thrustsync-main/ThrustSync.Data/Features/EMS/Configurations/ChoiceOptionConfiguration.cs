using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ThrustSync.Core.Features.EMS.Models;
using ThrustSync.Data.Features.EMS.Seed;

namespace ThrustSync.Data.Features.EMS.Configurations;

public class ChoiceOptionConfiguration : IEntityTypeConfiguration<ChoiceOption>
{
    public void Configure(EntityTypeBuilder<ChoiceOption> entity)
    {
        entity.ToTable("ChoiceOptions", "EMS");
        entity.HasKey(option => new { option.Type, option.Value });

        entity.Property(option => option.Type)
            .HasMaxLength(100)
            .IsRequired();

        entity.Property(option => option.Value)
            .HasMaxLength(255)
            .IsRequired();

        entity.HasData(EmsChoiceOptionSeed.All);
    }
}
