using ClosedXML.Excel;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ThrustSync.Core.Features.EMS.Models;
using ThrustSync.Data.Context;
using ThrustSync.Data.Features.EMS.Seed;
using System.Globalization;

namespace ThrustSync.ETL.Features.EMS.Jobs;

public class EmsExcelImportJob
{
    private const int DeleteBatchSize = 1000;
    private const int MaximumReportedErrors = 100;

    private static readonly string[] OptionalHeaders =
    [
        "Margin",
        "General Remarks",
        "Test Cell / Last Flight",
        "720 Due",
        "Assigned to Ship",
        "CANN Task Status",
        "Check Preservation",
        "Classification",
        "Current Location",
        "Est. Departure Date",
        "Engine Ship Category",
        "Engine Status",
        "Est Arrival Date",
        "Indefinite Preservation Date",
        "In Transit",
        "Last 15 Day Humidifier Inspection",
        "Last Preservation",
        "Next 15 Day Humidifier Inspection Due",
        "Next Preservation Due",
        "On Dock Date",
        "Preservation Type",
        "Scheduled Preservation",
        "Ship Destination",
        "Ship Origination",
        "Speedline",
        "60 Days for Alt I 180",
        "Spare Engines",
        "Training Engine",
        "In Grief Notes",
        "Assigned",
        "Unserv Report Group"
    ];

    private static readonly Dictionary<string, HashSet<string>> ChoiceValues =
        EmsChoiceOptionSeed.All
            .GroupBy(option => option.Type, StringComparer.Ordinal)
            .ToDictionary(
                group => group.Key,
                group => group.Select(option => option.Value).ToHashSet(StringComparer.Ordinal),
                StringComparer.Ordinal);

    private readonly TrustSyncDbContext _dbContext;
    private readonly ILogger<EmsExcelImportJob> _logger;

    public EmsExcelImportJob(TrustSyncDbContext dbContext, ILogger<EmsExcelImportJob> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    [AutomaticRetry(Attempts = 0)]
    public async Task ExecuteAsync(string filePath, string originalFileName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(filePath);

        try
        {
            _logger.LogInformation("Starting EMS data import for {FileName}", originalFileName);
            var records = ParseWorkbook(filePath, _logger);
            var engineSerialNumbers = records.Select(record => record.EngineSN).ToArray();

            var executionStrategy = _dbContext.Database.CreateExecutionStrategy();
            await executionStrategy.ExecuteAsync(async () =>
            {
                _dbContext.ChangeTracker.Clear();
                await using var transaction = await _dbContext.Database.BeginTransactionAsync();

                foreach (var engineSerialNumberBatch in engineSerialNumbers.Chunk(DeleteBatchSize))
                {
                    await _dbContext.EmsEngineRecords
                        .Where(record => engineSerialNumberBatch.Contains(record.EngineSN))
                        .ExecuteDeleteAsync();
                }

                await _dbContext.EmsEngineRecords.AddRangeAsync(records);
                await _dbContext.SaveChangesAsync();
                await transaction.CommitAsync();
            });

            _logger.LogInformation(
                "Completed EMS data import for {FileName}: {RecordCount} records loaded",
                originalFileName,
                records.Count);
        }
        finally
        {
            DeleteStagedFile(filePath);
        }
    }

    public static List<EngineRecord> ParseWorkbook(string filePath, ILogger logger)
    {
        using var workbook = new XLWorkbook(filePath);
        if (workbook.Worksheets.Count != 1)
        {
            throw new InvalidDataException(
                $"The EMS upload must contain exactly one worksheet; found {workbook.Worksheets.Count}.");
        }

        var worksheet = workbook.Worksheet(1);
        var headerRow = worksheet.Row(1);
        var lastColumn = worksheet.LastColumnUsed()?.ColumnNumber() ?? 0;
        if (lastColumn == 0)
        {
            throw new InvalidDataException("The EMS upload worksheet is empty.");
        }

        var columns = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        for (var column = 1; column <= lastColumn; column++)
        {
            var header = headerRow.Cell(column).GetString().Trim();
            if (header.Length == 0)
            {
                continue;
            }

            if (!columns.TryAdd(header, column))
            {
                throw new InvalidDataException($"The EMS upload contains a duplicate column header: '{header}'.");
            }
        }

        if (!columns.TryGetValue("Engine SN", out var engineSnColumn))
        {
            throw new InvalidDataException("The EMS upload is missing the required 'Engine SN' column.");
        }

        var missingHeaders = OptionalHeaders
            .Where(header => !columns.ContainsKey(header))
            .ToArray();
        if (missingHeaders.Length > 0)
        {
            logger.LogWarning(
                "EMS upload is missing optional columns; their values will be null: {MissingHeaders}",
                string.Join(", ", missingHeaders));
        }

        var lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 1;
        var records = new List<EngineRecord>(Math.Max(0, lastRow - 1));
        var seenEngineSerialNumbers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var errors = new List<string>();
        var validationErrorCount = 0;

        for (var rowNumber = 2; rowNumber <= lastRow; rowNumber++)
        {
            var row = worksheet.Row(rowNumber);
            if (row.Cells(1, lastColumn).All(cell => cell.IsEmpty()))
            {
                continue;
            }

            try
            {
                var engineSN = GetText(row, columns, "Engine SN");
                if (string.IsNullOrWhiteSpace(engineSN))
                {
                    throw new FormatException("'Engine SN' is required.");
                }

                engineSN = engineSN.Trim();
                if (!seenEngineSerialNumbers.Add(engineSN))
                {
                    throw new FormatException($"Duplicate Engine SN '{engineSN}' in the upload.");
                }

                records.Add(MapRecord(row, columns, engineSN));
            }
            catch (FormatException exception)
            {
                validationErrorCount++;
                if (errors.Count < MaximumReportedErrors)
                {
                    errors.Add($"Row {rowNumber}: {exception.Message}");
                }
            }
        }

        if (errors.Count > 0)
        {
            var omittedCount = validationErrorCount - errors.Count;
            throw new InvalidDataException(
                $"EMS upload validation failed:{Environment.NewLine}{string.Join(Environment.NewLine, errors)}" +
                (omittedCount > 0 ? $"{Environment.NewLine}And {omittedCount} additional errors." : string.Empty));
        }

        if (records.Count == 0)
        {
            throw new InvalidDataException("The EMS upload contains no engine records.");
        }

        return records;
    }

    private static EngineRecord MapRecord(
        IXLRow row,
        IReadOnlyDictionary<string, int> columns,
        string engineSN)
    {
        return new EngineRecord
        {
            EngineSN = engineSN,
            Margin = GetDecimal(row, columns, "Margin"),
            GeneralRemarks = GetText(row, columns, "General Remarks"),
            TestCellLastFlight = GetDate(row, columns, "Test Cell / Last Flight"),
            Due720 = GetDate(row, columns, "720 Due"),
            AssignedToShip = GetText(row, columns, "Assigned to Ship"),
            CANNTaskStatus = GetBoolean(row, columns, "CANN Task Status"),
            CheckPreservation = GetChoice(row, columns, "Check Preservation"),
            Classification = GetChoice(row, columns, "Classification"),
            CurrentLocation = GetChoice(row, columns, "Current Location"),
            EstimatedDepartureDate = GetDate(row, columns, "Est. Departure Date"),
            EngineShipCategory = GetChoice(row, columns, "Engine Ship Category"),
            EngineStatus = GetText(row, columns, "Engine Status"),
            EstimatedArrivalDate = GetDate(row, columns, "Est Arrival Date"),
            IndefinitePreservationDate = GetDate(row, columns, "Indefinite Preservation Date"),
            InTransit = GetBoolean(row, columns, "In Transit"),
            LastHumidifierInspectionDate = GetDate(row, columns, "Last 15 Day Humidifier Inspection"),
            LastPreservation = GetDate(row, columns, "Last Preservation"),
            NextHumidifierInspectionDue = GetDate(row, columns, "Next 15 Day Humidifier Inspection Due"),
            NextPreservationDue = GetDate(row, columns, "Next Preservation Due"),
            OnDockDate = GetDate(row, columns, "On Dock Date"),
            PreservationType = GetChoice(row, columns, "Preservation Type"),
            ScheduledPreservation = GetDate(row, columns, "Scheduled Preservation"),
            ShipDestination = GetChoice(row, columns, "Ship Destination"),
            ShipOrigination = GetChoice(row, columns, "Ship Origination"),
            Speedline = GetBoolean(row, columns, "Speedline"),
            AltI180DueDate = GetDate(row, columns, "60 Days for Alt I 180"),
            SpareEngines = GetText(row, columns, "Spare Engines"),
            TrainingEngine = GetBoolean(row, columns, "Training Engine"),
            InGriefNotes = GetText(row, columns, "In Grief Notes"),
            Assigned = GetText(row, columns, "Assigned"),
            UnserviceableReportGroup = GetText(row, columns, "Unserv Report Group"),
            CreatedBemsID = 0,
            ModifiedBemsId = null,
            ModifiedDate = null
        };
    }

    private static string? GetText(IXLRow row, IReadOnlyDictionary<string, int> columns, string header)
    {
        if (!columns.TryGetValue(header, out var column))
        {
            return null;
        }

        var value = row.Cell(column).GetString();
        return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
    }

    private static string? GetChoice(IXLRow row, IReadOnlyDictionary<string, int> columns, string header)
    {
        var value = GetText(row, columns, header);
        if (value is null)
        {
            return null;
        }

        if (!ChoiceValues[header].Contains(value))
        {
            throw new FormatException($"'{value}' is not an allowed value for '{header}'.");
        }

        return value;
    }

    private static decimal? GetDecimal(IXLRow row, IReadOnlyDictionary<string, int> columns, string header)
    {
        if (!columns.TryGetValue(header, out var column) || row.Cell(column).IsEmpty())
        {
            return null;
        }

        var cell = row.Cell(column);
        if (cell.TryGetValue<decimal>(out var value))
        {
            return value;
        }

        var text = cell.GetString().Trim();
        if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.CurrentCulture, out value) ||
            decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out value))
        {
            return value;
        }

        throw new FormatException($"'{cell.GetString()}' is not a valid number for '{header}'.");
    }

    private static DateTime? GetDate(IXLRow row, IReadOnlyDictionary<string, int> columns, string header)
    {
        if (!columns.TryGetValue(header, out var column) || row.Cell(column).IsEmpty())
        {
            return null;
        }

        var cell = row.Cell(column);
        if (cell.TryGetValue<DateTime>(out var value))
        {
            return value.Date;
        }

        var text = cell.GetString().Trim();
        if (DateTime.TryParse(text, CultureInfo.CurrentCulture, DateTimeStyles.AllowWhiteSpaces, out value) ||
            DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out value))
        {
            return value.Date;
        }

        throw new FormatException($"'{cell.GetString()}' is not a valid date for '{header}'.");
    }

    private static bool? GetBoolean(IXLRow row, IReadOnlyDictionary<string, int> columns, string header)
    {
        if (!columns.TryGetValue(header, out var column) || row.Cell(column).IsEmpty())
        {
            return null;
        }

        var cell = row.Cell(column);
        if (cell.TryGetValue<bool>(out var value))
        {
            return value;
        }

        var text = cell.GetString().Trim();
        if (text == "1" || text.Equals("Yes", StringComparison.OrdinalIgnoreCase) ||
            text.Equals("True", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        if (text == "0" || text.Equals("No", StringComparison.OrdinalIgnoreCase) ||
            text.Equals("False", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        throw new FormatException($"'{cell.GetString()}' is not a valid boolean for '{header}'.");
    }

    private void DeleteStagedFile(string filePath)
    {
        try
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }
        catch (IOException exception)
        {
            _logger.LogError(exception, "Could not delete staged EMS upload file {FilePath}", filePath);
        }
        catch (UnauthorizedAccessException exception)
        {
            _logger.LogError(exception, "Could not delete staged EMS upload file {FilePath}", filePath);
        }
    }
}
