(function ($) {
    "use strict";

    const $grid = $("#ems-engine-records");
    if (!$grid.length) {
        return;
    }

    const modal = new bootstrap.Modal(document.getElementById("engine-record-modal"));
    const state = {
        page: 1,
        pageSize: Number($("#engine-record-page-size").val()) || 25,
        search: "",
        sortBy: "EngineSN",
        sortDirection: "asc",
        total: 0
    };

    function showGridError(message) {
        $("#engine-record-error").text(message).removeClass("d-none");
    }

    function addCell($row, value) {
        $("<td>").text(value == null || value === "" ? "-" : value).appendTo($row);
    }

    function loadRecords() {
        $("#engine-record-error").addClass("d-none").text("");
        $("#engine-record-status").text("Loading...");

        $.getJSON($grid.data("data-url"), state)
            .done(function (result) {
                state.page = result.page;
                state.total = result.total;
                const $rows = $("#engine-record-rows").empty();

                if (!result.items.length) {
                    $("<tr>").append(
                        $("<td>", { colspan: 7, class: "text-center text-muted py-4" })
                            .text("No engine records found.")
                    ).appendTo($rows);
                } else {
                    result.items.forEach(function (item) {
                        const $row = $("<tr>");
                        addCell($row, item.engineSN);
                        addCell($row, item.classification);
                        addCell($row, item.currentLocation);
                        addCell($row, item.engineStatus);
                        addCell($row, item.engineShipCategory);
                        addCell($row, item.due720 ? item.due720.substring(0, 10) : "");

                        const $actionCell = $("<td>", { class: "text-end" });
                        $("<button>", {
                            type: "button",
                            class: "btn btn-sm btn-outline-primary edit-engine-record",
                            text: "Edit"
                        }).attr("data-engine-sn", item.engineSN).appendTo($actionCell);
                        $row.append($actionCell).appendTo($rows);
                    });
                }

                const start = result.total === 0 ? 0 : (result.page - 1) * result.pageSize + 1;
                const end = Math.min(result.page * result.pageSize, result.total);
                $("#engine-record-count").text("Showing " + start + "–" + end + " of " + result.total);
                $("#engine-record-status").text("");
                $("#engine-record-previous").prop("disabled", result.page <= 1);
                $("#engine-record-next").prop("disabled", end >= result.total);
            })
            .fail(function () {
                $("#engine-record-status").text("");
                showGridError("Engine records could not be loaded. Please try again.");
            });
    }

    function openForm(url) {
        $("#engine-record-modal-content").empty();
        $.get(url)
            .done(function (html) {
                $("#engine-record-modal-content").html(html);
                modal.show();
            })
            .fail(function (xhr) {
                showGridError(xhr.status === 404
                    ? "The requested engine record was not found."
                    : "The form could not be loaded. Please try again.");
            });
    }

    $("#create-engine-record").on("click", function () {
        openForm($grid.data("create-url"));
    });

    $("#engine-record-rows").on("click", ".edit-engine-record", function () {
        const engineSN = $(this).attr("data-engine-sn");
        const url = $grid.data("edit-url").replace("__engineSN__", encodeURIComponent(engineSN));
        openForm(url);
    });

    $("#engine-record-modal-content").on("submit", "#engine-record-form", function (event) {
        event.preventDefault();
        const $form = $(this);
        const $submit = $form.find('button[type="submit"]');
        const $errors = $("#engine-record-form-errors").addClass("d-none").empty();
        $submit.prop("disabled", true);

        $.ajax({
            url: $form.attr("action"),
            method: "POST",
            data: $form.serialize()
        })
            .done(function () {
                modal.hide();
                loadRecords();
            })
            .fail(function (xhr) {
                if (xhr.status === 400 && xhr.responseJSON && xhr.responseJSON.errors) {
                    const messages = [];
                    Object.keys(xhr.responseJSON.errors).forEach(function (key) {
                        xhr.responseJSON.errors[key].forEach(function (message) {
                            messages.push(message);
                        });
                    });
                    $errors.text(messages.join(" "));
                } else if (xhr.status === 404) {
                    $errors.text("This engine record no longer exists. Close the form and refresh the grid.");
                } else {
                    $errors.text("The record could not be saved. Please try again.");
                }

                $errors.removeClass("d-none");
            })
            .always(function () {
                $submit.prop("disabled", false);
            });
    });

    $("#engine-record-search").on("input", function () {
        const input = this;
        window.clearTimeout(input.searchTimer);
        input.searchTimer = window.setTimeout(function () {
            state.search = input.value;
            state.page = 1;
            loadRecords();
        }, 300);
    });

    $("#engine-record-page-size").on("change", function () {
        state.pageSize = Number(this.value) || 25;
        state.page = 1;
        loadRecords();
    });

    $(".sort-engine-record").on("click", function () {
        const requestedSort = $(this).data("sort");
        state.sortDirection = state.sortBy === requestedSort && state.sortDirection === "asc" ? "desc" : "asc";
        state.sortBy = requestedSort;
        state.page = 1;
        loadRecords();
    });

    $("#engine-record-previous").on("click", function () {
        if (state.page > 1) {
            state.page--;
            loadRecords();
        }
    });

    $("#engine-record-next").on("click", function () {
        if (state.page * state.pageSize < state.total) {
            state.page++;
            loadRecords();
        }
    });

    loadRecords();
})(jQuery);
