using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc.Razor;
using ThrustSync.Core.Features.ThrustSync.Models;
using ThrustSync.Core.Features.ThrustSync.Repositories;
using ThrustSync.Core.Features.ThrustSync.Services;
using ThrustSync.Data.Features.ThrustSync.Repositories;
using ThrustSync.ETL.Features.ThrustSync.Jobs;
using ThrustSync.ETL.Features.ThrustSync.Services;
using ThrustSync.Web.Features.ThrustSync.Services;

namespace ThrustSync.Web.Features.ThrustSync;

public static class ThrustSyncServiceCollectionExtensions
{
    public static IServiceCollection AddThrustSyncFeature(this IServiceCollection services)
    {
        services.Configure<RazorViewEngineOptions>(options =>
        {
            options.ViewLocationFormats.Insert(0, "/Features/ThrustSync/Views/{1}/{0}.cshtml");
        });

        services.AddScoped<IRepository<AuditLog>, Repository<AuditLog>>();
        services.AddScoped<IRepository<ExportLog>, Repository<ExportLog>>();
        services.AddScoped<IWorkOrderRepository, WorkOrderRepository>();
        services.AddScoped<IKpiEntryRepository, KpiEntryRepository>();

        services.AddScoped<IWorkOrderService, WorkOrderService>();
        services.AddScoped<IKpiService, KpiService>();
        services.AddScoped<IAuditService, AuditService>();

        services.AddScoped<IOracleService, OracleService>();
        services.AddScoped<OracleEtlJob>();
        services.AddScoped<IExcelExportService, ExcelExportService>();

        return services;
    }
}
