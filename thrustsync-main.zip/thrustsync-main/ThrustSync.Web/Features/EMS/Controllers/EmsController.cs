using System;
using System.IO;
using System.Threading.Tasks;
using Hangfire;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ThrustSync.ETL.Features.EMS.Jobs;
using ThrustSync.Web.Features.EMS.Models;

namespace ThrustSync.Web.Features.EMS.Controllers;

[Route("Ems")]
public class EmsController : Controller
{
    private const long MaximumUploadSize = 20 * 1024 * 1024;
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly IConfiguration _configuration;
    private readonly IWebHostEnvironment _environment;
    private readonly ILogger<EmsController> _logger;

    public EmsController(
        IBackgroundJobClient backgroundJobClient,
        IConfiguration configuration,
        IWebHostEnvironment environment,
        ILogger<EmsController> logger)
    {
        _backgroundJobClient = backgroundJobClient;
        _configuration = configuration;
        _environment = environment;
        _logger = logger;
    }

    [HttpGet("dataupload")]
    public IActionResult DataUpload()
    {
        if (!IsUploadEnabled())
        {
            return NotFound();
        }

        return View(new EmsDataUploadViewModel());
    }

    [HttpPost("dataupload")]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(MaximumUploadSize)]
    public async Task<IActionResult> DataUpload(EmsDataUploadViewModel model)
    {
        if (!IsUploadEnabled())
        {
            return NotFound();
        }

        if (model.File is null || model.File.Length == 0)
        {
            ModelState.AddModelError(nameof(model.File), "Select a non-empty Excel workbook.");
            return View(model);
        }

        if (!string.Equals(Path.GetExtension(model.File.FileName), ".xlsx", StringComparison.OrdinalIgnoreCase))
        {
            ModelState.AddModelError(nameof(model.File), "Upload an .xlsx workbook.");
            return View(model);
        }

        if (model.File.Length > MaximumUploadSize)
        {
            ModelState.AddModelError(nameof(model.File), "The workbook must be 20 MB or smaller.");
            return View(model);
        }

        var stagingDirectory = Path.Combine(_environment.ContentRootPath, "App_Data", "EMSUploads");
        var stagedFilePath = Path.Combine(stagingDirectory, $"{Guid.NewGuid():N}.xlsx");
        var originalFileName = Path.GetFileName(model.File.FileName);
        var queued = false;

        try
        {
            Directory.CreateDirectory(stagingDirectory);
            await using (var stream = new FileStream(
                stagedFilePath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None,
                bufferSize: 81920,
                useAsync: true))
            {
                await model.File.CopyToAsync(stream);
            }

            model.JobId = _backgroundJobClient.Enqueue<EmsExcelImportJob>(
                job => job.ExecuteAsync(stagedFilePath, originalFileName));
            queued = true;
            _logger.LogInformation("Queued EMS workbook upload as Hangfire job {JobId}", model.JobId);
            return View(model);
        }
        catch (IOException exception)
        {
            _logger.LogError(exception, "Could not stage the EMS workbook upload");
            ModelState.AddModelError(string.Empty, "The workbook could not be queued. Check the application logs and try again.");
            return View(model);
        }
        catch (UnauthorizedAccessException exception)
        {
            _logger.LogError(exception, "Could not access the EMS workbook staging directory");
            ModelState.AddModelError(string.Empty, "The workbook could not be queued. Check the application logs and try again.");
            return View(model);
        }
        finally
        {
            if (!queued && System.IO.File.Exists(stagedFilePath))
            {
                try
                {
                    System.IO.File.Delete(stagedFilePath);
                }
                catch (IOException exception)
                {
                    _logger.LogError(exception, "Could not delete staged EMS upload {FilePath}", stagedFilePath);
                }
                catch (UnauthorizedAccessException exception)
                {
                    _logger.LogError(exception, "Could not delete staged EMS upload {FilePath}", stagedFilePath);
                }
            }
        }
    }

    private bool IsUploadEnabled() =>
        _configuration.GetValue<bool>("EmsDataUpload:Enabled");
}
