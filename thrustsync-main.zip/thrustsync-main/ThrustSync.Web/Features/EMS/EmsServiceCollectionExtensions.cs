using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc.Razor;
using ThrustSync.ETL.Features.EMS.Jobs;

namespace ThrustSync.Web.Features.EMS;

public static class EmsServiceCollectionExtensions
{
    public static IServiceCollection AddEmsFeature(this IServiceCollection services)
    {
        services.Configure<RazorViewEngineOptions>(options =>
        {
            options.ViewLocationFormats.Insert(0, "/Features/EMS/Views/{1}/{0}.cshtml");
        });

        services.AddScoped<EmsExcelImportJob>();
        return services;
    }
}
