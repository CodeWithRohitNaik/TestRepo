using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using ThrustSync.Core.Features.EMS.Models;

namespace ThrustSync.Web.Features.EMS.Models;

public class EmsEngineRecordEditViewModel
{
    [Required]
    [StringLength(255)]
    public string EngineSN { get; set; } = string.Empty;

    public bool IsEdit { get; set; }
    public decimal? Margin { get; set; }
    public string? GeneralRemarks { get; set; }
    public DateTime? TestCellLastFlight { get; set; }
    public DateTime? Due720 { get; set; }

    [StringLength(255)]
    public string? AssignedToShip { get; set; }

    public bool? CANNTaskStatus { get; set; }

    [StringLength(50)]
    public string? CheckPreservation { get; set; }

    [StringLength(30)]
    public string? Classification { get; set; }

    [StringLength(255)]
    public string? CurrentLocation { get; set; }

    public DateTime? EstimatedDepartureDate { get; set; }

    [StringLength(30)]
    public string? EngineShipCategory { get; set; }

    [StringLength(50)]
    public string? EngineStatus { get; set; }

    public DateTime? EstimatedArrivalDate { get; set; }
    public DateTime? IndefinitePreservationDate { get; set; }
    public bool? InTransit { get; set; }
    public DateTime? LastHumidifierInspectionDate { get; set; }
    public DateTime? LastPreservation { get; set; }
    public DateTime? NextHumidifierInspectionDue { get; set; }
    public DateTime? NextPreservationDue { get; set; }
    public DateTime? OnDockDate { get; set; }

    [StringLength(100)]
    public string? PreservationType { get; set; }

    public DateTime? ScheduledPreservation { get; set; }

    [StringLength(255)]
    public string? ShipDestination { get; set; }

    [StringLength(255)]
    public string? ShipOrigination { get; set; }

    public bool? Speedline { get; set; }
    public DateTime? AltI180DueDate { get; set; }

    [StringLength(50)]
    public string? SpareEngines { get; set; }

    public bool? TrainingEngine { get; set; }
    public string? InGriefNotes { get; set; }

    [StringLength(100)]
    public string? UnserviceableReportGroup { get; set; }

    public List<string> CheckPreservationOptions { get; set; } = [];
    public List<string> ClassificationOptions { get; set; } = [];
    public List<string> CurrentLocationOptions { get; set; } = [];
    public List<string> EngineShipCategoryOptions { get; set; } = [];
    public List<string> PreservationTypeOptions { get; set; } = [];
    public List<string> ShipDestinationOptions { get; set; } = [];
    public List<string> ShipOriginationOptions { get; set; } = [];

    public EngineRecord ToEngineRecord() => new()
    {
        EngineSN = EngineSN.Trim(),
        Margin = Margin,
        GeneralRemarks = GeneralRemarks,
        TestCellLastFlight = TestCellLastFlight,
        Due720 = Due720,
        AssignedToShip = AssignedToShip,
        CANNTaskStatus = CANNTaskStatus,
        CheckPreservation = CheckPreservation,
        Classification = Classification,
        CurrentLocation = CurrentLocation,
        EstimatedDepartureDate = EstimatedDepartureDate,
        EngineShipCategory = EngineShipCategory,
        EngineStatus = EngineStatus,
        EstimatedArrivalDate = EstimatedArrivalDate,
        IndefinitePreservationDate = IndefinitePreservationDate,
        InTransit = InTransit,
        LastHumidifierInspectionDate = LastHumidifierInspectionDate,
        LastPreservation = LastPreservation,
        NextHumidifierInspectionDue = NextHumidifierInspectionDue,
        NextPreservationDue = NextPreservationDue,
        OnDockDate = OnDockDate,
        PreservationType = PreservationType,
        ScheduledPreservation = ScheduledPreservation,
        ShipDestination = ShipDestination,
        ShipOrigination = ShipOrigination,
        Speedline = Speedline,
        AltI180DueDate = AltI180DueDate,
        SpareEngines = SpareEngines,
        TrainingEngine = TrainingEngine,
        InGriefNotes = InGriefNotes,
        UnserviceableReportGroup = UnserviceableReportGroup
    };

    public void ApplyTo(EngineRecord record)
    {
        record.Margin = Margin;
        record.GeneralRemarks = GeneralRemarks;
        record.TestCellLastFlight = TestCellLastFlight;
        record.Due720 = Due720;
        record.AssignedToShip = AssignedToShip;
        record.CANNTaskStatus = CANNTaskStatus;
        record.CheckPreservation = CheckPreservation;
        record.Classification = Classification;
        record.CurrentLocation = CurrentLocation;
        record.EstimatedDepartureDate = EstimatedDepartureDate;
        record.EngineShipCategory = EngineShipCategory;
        record.EngineStatus = EngineStatus;
        record.EstimatedArrivalDate = EstimatedArrivalDate;
        record.IndefinitePreservationDate = IndefinitePreservationDate;
        record.InTransit = InTransit;
        record.LastHumidifierInspectionDate = LastHumidifierInspectionDate;
        record.LastPreservation = LastPreservation;
        record.NextHumidifierInspectionDue = NextHumidifierInspectionDue;
        record.NextPreservationDue = NextPreservationDue;
        record.OnDockDate = OnDockDate;
        record.PreservationType = PreservationType;
        record.ScheduledPreservation = ScheduledPreservation;
        record.ShipDestination = ShipDestination;
        record.ShipOrigination = ShipOrigination;
        record.Speedline = Speedline;
        record.AltI180DueDate = AltI180DueDate;
        record.SpareEngines = SpareEngines;
        record.TrainingEngine = TrainingEngine;
        record.InGriefNotes = InGriefNotes;
        record.UnserviceableReportGroup = UnserviceableReportGroup;
    }
}
