using Microsoft.AspNetCore.Http;

namespace ThrustSync.Web.Features.EMS.Models;

public class EmsDataUploadViewModel
{
    public IFormFile? File { get; set; }
    public string? JobId { get; set; }
}
