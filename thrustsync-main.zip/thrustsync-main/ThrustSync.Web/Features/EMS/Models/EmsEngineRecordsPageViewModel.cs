namespace ThrustSync.Web.Features.EMS.Models;

public class EmsEngineRecordsPageViewModel
{
    public int PageSize { get; set; } = 25;
}
