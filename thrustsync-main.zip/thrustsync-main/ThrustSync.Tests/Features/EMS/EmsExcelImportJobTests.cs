using System;
using System.IO;
using System.Linq;
using ClosedXML.Excel;
using Microsoft.Extensions.Logging.Abstractions;
using ThrustSync.ETL.Features.EMS.Jobs;
using Xunit;

namespace ThrustSync.Tests.Features.EMS;

public class EmsExcelImportJobTests
{
    [Fact]
    public void ParseWorkbook_MapsDisplayNamesAndIgnoresSharePointMetadata()
    {
        var path = CreateWorkbook(workbook =>
        {
            var sheet = workbook.Worksheet(1);
            SetCell(sheet, 1, "Engine SN", "Engine SN");
            SetCell(sheet, 1, "General Remarks", "General Remarks");
            SetCell(sheet, 1, "Test Cell / Last Flight", "Test Cell / Last Flight");
            SetCell(sheet, 1, "CANN Task Status", "CANN Task Status");
            SetCell(sheet, 1, "Check Preservation", "Check Preservation");
            SetCell(sheet, 1, "Classification", "Classification");
            SetCell(sheet, 1, "Current Location", "Current Location");
            SetCell(sheet, 1, "Item Type", "Item Type");
            SetCell(sheet, 1, "Path", "Path");

            SetCell(sheet, 2, "Engine SN", "170001");
            SetCell(sheet, 2, "General Remarks", "  Test engine  ");
            SetCell(sheet, 2, "Test Cell / Last Flight", new DateTime(2026, 11, 1, 13, 30, 0));
            SetCell(sheet, 2, "CANN Task Status", 0);
            SetCell(sheet, 2, "Check Preservation", "Check 720");
            SetCell(sheet, 2, "Classification", "IN GRIEF");
            SetCell(sheet, 2, "Current Location", "Davis-Monthan, AZ");
            SetCell(sheet, 2, "Item Type", "Item");
            SetCell(sheet, 2, "Path", "SharePoint path");
        });

        try
        {
            var records = EmsExcelImportJob.ParseWorkbook(path, NullLogger.Instance);

            var record = Assert.Single(records);
            Assert.Equal("170001", record.EngineSN);
            Assert.Equal("Test engine", record.GeneralRemarks);
            Assert.Equal(new DateTime(2026, 11, 1), record.TestCellLastFlight);
            Assert.False(record.CANNTaskStatus);
            Assert.Equal("Check 720", record.CheckPreservation);
            Assert.Equal("IN GRIEF", record.Classification);
            Assert.Equal("Davis-Monthan, AZ", record.CurrentLocation);
            Assert.Null(record.Assigned);
            Assert.Null(record.UnserviceableReportGroup);
            Assert.Equal(0, record.CreatedBemsID);
            Assert.Null(record.ModifiedDate);
        }
        finally
        {
            File.Delete(path);
        }
    }

    [Fact]
    public void ParseWorkbook_RejectsWorkbookWithMoreThanOneWorksheet()
    {
        var path = CreateWorkbook(workbook => workbook.AddWorksheet("Second"));

        try
        {
            var exception = Assert.Throws<InvalidDataException>(
                () => EmsExcelImportJob.ParseWorkbook(path, NullLogger.Instance));

            Assert.Contains("exactly one worksheet", exception.Message);
        }
        finally
        {
            File.Delete(path);
        }
    }

    [Fact]
    public void ParseWorkbook_RejectsDuplicateEngineNumbersAndInvalidChoices()
    {
        var path = CreateWorkbook(workbook =>
        {
            var sheet = workbook.Worksheet(1);
            SetCell(sheet, 1, "Engine SN", "Engine SN");
            SetCell(sheet, 1, "Classification", "Classification");
            SetCell(sheet, 2, "Engine SN", "170001");
            SetCell(sheet, 2, "Classification", "Unknown");
            SetCell(sheet, 3, "Engine SN", "170001");
            SetCell(sheet, 3, "Classification", "SPS");
        });

        try
        {
            var exception = Assert.Throws<InvalidDataException>(
                () => EmsExcelImportJob.ParseWorkbook(path, NullLogger.Instance));

            Assert.Contains("not an allowed value", exception.Message);
            Assert.Contains("Duplicate Engine SN", exception.Message);
        }
        finally
        {
            File.Delete(path);
        }
    }

    private static string CreateWorkbook(Action<XLWorkbook> configure)
    {
        var path = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.xlsx");
        using var workbook = new XLWorkbook();
        workbook.AddWorksheet("EMS");
        configure(workbook);
        workbook.SaveAs(path);
        return path;
    }

    private static void SetCell(IXLWorksheet worksheet, int row, string header, object value)
    {
        var headers = worksheet.Row(1);
        var lastColumn = Math.Max(1, headers.LastCellUsed()?.Address.ColumnNumber ?? 0);
        var column = Enumerable.Range(1, lastColumn)
            .FirstOrDefault(index => headers.Cell(index).GetString() == header);

        if (column == 0)
        {
            column = lastColumn + 1;
            headers.Cell(column).Value = header;
        }

        worksheet.Cell(row, column).Value = XLCellValue.FromObject(value);
    }
}
