namespace ThrustSync.Core.Features.EMS.Models;

public class EngineRecord
{
    public string EngineSN { get; set; } = string.Empty;
    public decimal? Margin { get; set; }
    public string? GeneralRemarks { get; set; }
    public DateTime? TestCellLastFlight { get; set; }
    public DateTime? Due720 { get; set; }
    public string? AssignedToShip { get; set; }
    public bool? CANNTaskStatus { get; set; }
    public string? CheckPreservation { get; set; }
    public string? Classification { get; set; }
    public string? CurrentLocation { get; set; }
    public DateTime? EstimatedDepartureDate { get; set; }
    public string? EngineShipCategory { get; set; }
    public string? EngineStatus { get; set; }
    public DateTime? EstimatedArrivalDate { get; set; }
    public DateTime? IndefinitePreservationDate { get; set; }
    public bool? InTransit { get; set; }
    public DateTime? LastHumidifierInspectionDate { get; set; }
    public DateTime? LastPreservation { get; set; }
    public DateTime? NextHumidifierInspectionDue { get; set; }
    public DateTime? NextPreservationDue { get; set; }
    public DateTime? OnDockDate { get; set; }
    public string? PreservationType { get; set; }
    public DateTime? ScheduledPreservation { get; set; }
    public string? ShipDestination { get; set; }
    public string? ShipOrigination { get; set; }
    public bool? Speedline { get; set; }
    public DateTime? AltI180DueDate { get; set; }
    public string? SpareEngines { get; set; }
    public bool? TrainingEngine { get; set; }
    public string? InGriefNotes { get; set; }
    public string? Assigned { get; set; }
    public string? UnserviceableReportGroup { get; set; }
    public int CreatedBemsID { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBemsId { get; set; }
    public DateTime? ModifiedDate { get; set; }
}
