namespace ThrustSync.Core.Features.EMS.Models;

public class ChoiceOption
{
    public string Type { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}
