using ThrustSync.Core.Features.EMS.Models;

namespace ThrustSync.Core.Features.EMS.Repositories;

public interface IEmsEngineRecordRepository
{
    Task<(IReadOnlyList<EngineRecord> Items, int Total, int Page)> GetPageAsync(
        int page,
        int pageSize,
        string? search,
        string sortBy,
        bool descending);

    Task<EngineRecord?> GetByEngineSNAsync(string engineSN);
    Task<bool> ExistsAsync(string engineSN);
    Task<Dictionary<string, List<string>>> GetChoiceOptionsAsync();
    Task AddAsync(EngineRecord record);
    Task UpdateAsync(EngineRecord record);
}
