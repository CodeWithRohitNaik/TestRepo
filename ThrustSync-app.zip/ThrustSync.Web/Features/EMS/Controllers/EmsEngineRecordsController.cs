using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ThrustSync.Core.Features.EMS.Models;
using ThrustSync.Core.Features.EMS.Repositories;
using ThrustSync.Web.Features.EMS.Models;

namespace ThrustSync.Web.Features.EMS.Controllers;

[Route("Ems/EngineRecords")]
public class EmsEngineRecordsController : Controller
{
    private const int DefaultPageSize = 25;
    private readonly IEmsEngineRecordRepository _repository;
    private readonly ILogger<EmsEngineRecordsController> _logger;

    public EmsEngineRecordsController(
        IEmsEngineRecordRepository repository,
        ILogger<EmsEngineRecordsController> logger)
    {
        _repository = repository;
        _logger = logger;
    }

    [HttpGet("")]
    public IActionResult Index() =>
        View("~/Features/EMS/Views/EngineRecords/Index.cshtml", new EmsEngineRecordsPageViewModel());

    [HttpGet("data")]
    public async Task<IActionResult> Data(
        int page = 1,
        int pageSize = DefaultPageSize,
        string? search = null,
        string sortBy = "EngineSN",
        string sortDirection = "asc")
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var descending = string.Equals(sortDirection, "desc", StringComparison.OrdinalIgnoreCase);
        var result = await _repository.GetPageAsync(page, pageSize, search?.Trim(), sortBy, descending);

        return Json(new
        {
            items = result.Items.Select(record => new
            {
                record.EngineSN,
                record.Classification,
                record.CurrentLocation,
                record.EngineStatus,
                record.EngineShipCategory,
                record.Due720
            }),
            total = result.Total,
            page = result.Page,
            pageSize
        });
    }

    [HttpGet("create")]
    public async Task<IActionResult> Create()
    {
        var model = await WithChoiceOptionsAsync(new EmsEngineRecordEditViewModel());
        return PartialView("~/Features/EMS/Views/EngineRecords/_Form.cshtml", model);
    }

    [HttpPost("create")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(EmsEngineRecordEditViewModel model)
    {
        model.IsEdit = false;
        var choices = await _repository.GetChoiceOptionsAsync();
        ValidateChoices(model, choices);
        var engineSN = model.EngineSN?.Trim() ?? string.Empty;
        if (await _repository.ExistsAsync(engineSN))
        {
            ModelState.AddModelError(nameof(model.EngineSN), "An engine record with this serial number already exists.");
        }

        if (!ModelState.IsValid)
        {
            ApplyChoiceOptions(model, choices);
            return BadRequest(ValidationErrors());
        }

        var record = model.ToEngineRecord();
        await _repository.AddAsync(record);
        _logger.LogInformation("Created EMS engine record {EngineSN}", record.EngineSN);
        return Json(new { success = true });
    }

    [HttpGet("edit/{engineSN}", Name = "EmsEngineRecordEdit")]
    public async Task<IActionResult> Edit(string engineSN)
    {
        var record = await _repository.GetByEngineSNAsync(engineSN);
        if (record is null)
        {
            return NotFound();
        }

        var choices = await _repository.GetChoiceOptionsAsync();
        var model = ToViewModel(record);
        model.IsEdit = true;
        ApplyChoiceOptions(model, choices);
        return PartialView("~/Features/EMS/Views/EngineRecords/_Form.cshtml", model);
    }

    [HttpPost("edit/{engineSN}")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(string engineSN, EmsEngineRecordEditViewModel model)
    {
        model.IsEdit = true;
        if (!string.Equals(engineSN, model.EngineSN, StringComparison.Ordinal))
        {
            ModelState.AddModelError(nameof(model.EngineSN), "The engine serial number cannot be changed.");
        }

        var choices = await _repository.GetChoiceOptionsAsync();
        ValidateChoices(model, choices);
        var record = await _repository.GetByEngineSNAsync(engineSN);
        if (record is null)
        {
            return NotFound();
        }

        if (!ModelState.IsValid)
        {
            ApplyChoiceOptions(model, choices);
            return BadRequest(ValidationErrors());
        }

        model.ApplyTo(record);
        record.ModifiedDate = DateTime.UtcNow;
        await _repository.UpdateAsync(record);
        _logger.LogInformation("Updated EMS engine record {EngineSN}", record.EngineSN);
        return Json(new { success = true });
    }

    private async Task<EmsEngineRecordEditViewModel> WithChoiceOptionsAsync(EmsEngineRecordEditViewModel model)
    {
        ApplyChoiceOptions(model, await _repository.GetChoiceOptionsAsync());
        return model;
    }

    private static void ApplyChoiceOptions(
        EmsEngineRecordEditViewModel model,
        IReadOnlyDictionary<string, List<string>> choices)
    {
        model.CheckPreservationOptions = GetOptions(choices, "Check Preservation");
        model.ClassificationOptions = GetOptions(choices, "Classification");
        model.CurrentLocationOptions = GetOptions(choices, "Current Location");
        model.EngineShipCategoryOptions = GetOptions(choices, "Engine Ship Category");
        model.PreservationTypeOptions = GetOptions(choices, "Preservation Type");
        model.ShipDestinationOptions = GetOptions(choices, "Ship Destination");
        model.ShipOriginationOptions = GetOptions(choices, "Ship Origination");
    }

    private static List<string> GetOptions(
        IReadOnlyDictionary<string, List<string>> choices,
        string type) =>
        choices.TryGetValue(type, out var values) ? values : [];

    private void ValidateChoices(
        EmsEngineRecordEditViewModel model,
        IReadOnlyDictionary<string, List<string>> choices)
    {
        ValidateChoice(model.CheckPreservation, "Check Preservation", nameof(model.CheckPreservation), choices);
        ValidateChoice(model.Classification, "Classification", nameof(model.Classification), choices);
        ValidateChoice(model.CurrentLocation, "Current Location", nameof(model.CurrentLocation), choices);
        ValidateChoice(model.EngineShipCategory, "Engine Ship Category", nameof(model.EngineShipCategory), choices);
        ValidateChoice(model.PreservationType, "Preservation Type", nameof(model.PreservationType), choices);
        ValidateChoice(model.ShipDestination, "Ship Destination", nameof(model.ShipDestination), choices);
        ValidateChoice(model.ShipOrigination, "Ship Origination", nameof(model.ShipOrigination), choices);
    }

    private void ValidateChoice(
        string? value,
        string type,
        string propertyName,
        IReadOnlyDictionary<string, List<string>> choices)
    {
        if (!string.IsNullOrEmpty(value) &&
            (!choices.TryGetValue(type, out var values) || !values.Contains(value, StringComparer.Ordinal)))
        {
            ModelState.AddModelError(propertyName, $"Select a valid {type} value.");
        }
    }

    private object ValidationErrors() => new
    {
        errors = ModelState
            .Where(entry => entry.Value?.Errors.Count > 0)
            .ToDictionary(
                entry => entry.Key,
                entry => entry.Value!.Errors.Select(error =>
                    string.IsNullOrEmpty(error.ErrorMessage) ? "The submitted value is invalid." : error.ErrorMessage))
    };

    private static EmsEngineRecordEditViewModel ToViewModel(EngineRecord record) => new()
    {
        EngineSN = record.EngineSN,
        Margin = record.Margin,
        GeneralRemarks = record.GeneralRemarks,
        TestCellLastFlight = record.TestCellLastFlight,
        Due720 = record.Due720,
        AssignedToShip = record.AssignedToShip,
        CANNTaskStatus = record.CANNTaskStatus,
        CheckPreservation = record.CheckPreservation,
        Classification = record.Classification,
        CurrentLocation = record.CurrentLocation,
        EstimatedDepartureDate = record.EstimatedDepartureDate,
        EngineShipCategory = record.EngineShipCategory,
        EngineStatus = record.EngineStatus,
        EstimatedArrivalDate = record.EstimatedArrivalDate,
        IndefinitePreservationDate = record.IndefinitePreservationDate,
        InTransit = record.InTransit,
        LastHumidifierInspectionDate = record.LastHumidifierInspectionDate,
        LastPreservation = record.LastPreservation,
        NextHumidifierInspectionDue = record.NextHumidifierInspectionDue,
        NextPreservationDue = record.NextPreservationDue,
        OnDockDate = record.OnDockDate,
        PreservationType = record.PreservationType,
        ScheduledPreservation = record.ScheduledPreservation,
        ShipDestination = record.ShipDestination,
        ShipOrigination = record.ShipOrigination,
        Speedline = record.Speedline,
        AltI180DueDate = record.AltI180DueDate,
        SpareEngines = record.SpareEngines,
        TrainingEngine = record.TrainingEngine,
        InGriefNotes = record.InGriefNotes,
        Assigned = record.Assigned,
        UnserviceableReportGroup = record.UnserviceableReportGroup
    };
}
